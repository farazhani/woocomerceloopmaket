(function ($) {
    // نمایش/مخفی کردن
    wp.customize('show_services_block', function (value) {
        value.bind(function (newval) {
            if (newval) {
                $('.services-block').show();
            } else {
                $('.services-block').hide();
            }
        });
    });

    // Border radius
    wp.customize('services_border_radius', function (value) {
        value.bind(function (newval) {
            $('.services-block').css('border-radius', newval);
        });
    });

    // رنگ پس‌زمینه
    wp.customize('services_bg_color', function (value) {
        value.bind(function (newval) {
            $('.services-block').css('background-color', newval);
        });
    });

    // سایه
    function updateShadow() {
        var x = wp.customize('services_shadow_x')();
        var y = wp.customize('services_shadow_y')();
        var blur = wp.customize('services_shadow_blur')();
        var spread = wp.customize('services_shadow_spread')();
        var color = wp.customize('services_shadow_color')();
        $('.services-block').css('box-shadow', x + ' ' + y + ' ' + blur + ' ' + spread + ' ' + color);
    }
    wp.customize('services_shadow_x', function (value) { value.bind(updateShadow); });
    wp.customize('services_shadow_y', function (value) { value.bind(updateShadow); });
    wp.customize('services_shadow_blur', function (value) { value.bind(updateShadow); });
    wp.customize('services_shadow_spread', function (value) { value.bind(updateShadow); });
    wp.customize('services_shadow_color', function (value) { value.bind(updateShadow); });
})(jQuery);


(function ($) {
    //  نمایش/مخفی شدن بلوک 2
    wp.customize('show_blocks2', function (value) {
        value.bind(function (newval) {
            if (newval) {
                $('#blocks2-wrapper').show();
            } else {
                $('#blocks2-wrapper').hide();
            }
        });
    });

    //  رنگ پس‌زمینه
    wp.customize('blocks2_bg_color', function (value) {
        value.bind(function (newval) {
            $('#blocks2-wrapper .blocks2-item').css('background-color', newval);
        });
    });

    //  Border Radius (کلاس Tailwind)
    wp.customize('blocks2_radius_class', function (value) {
        value.bind(function (newval) {
            $('#blocks2-wrapper .blocks2-item')
                .removeClass('rounded-none rounded-sm rounded-md rounded-lg rounded-xl')
                .addClass(newval);
        });
    });

    //  سایه‌ها
    function updateBlocks2Shadow() {
        let x = wp.customize('blocks2_shadow_x')(),
            y = wp.customize('blocks2_shadow_y')(),
            blur = wp.customize('blocks2_shadow_blur')(),
            spread = wp.customize('blocks2_shadow_spread')(),
            color = wp.customize('blocks2_shadow_color')();

        $('#blocks2-wrapper .blocks2-item').css('box-shadow', `${x} ${y} ${blur} ${spread} ${color}`);
    }

    ['blocks2_shadow_x', 'blocks2_shadow_y', 'blocks2_shadow_blur', 'blocks2_shadow_spread', 'blocks2_shadow_color']
        .forEach(function (setting) {
            wp.customize(setting, function (value) {
                value.bind(updateBlocks2Shadow);
            });
        });

})(jQuery);


wp.customize('show_banners', function (value) {
    value.bind(function (newval) {
        if (newval) {
            document.querySelector('#banners-wrapper')?.classList.remove('hidden');
        } else {
            document.querySelector('#banners-wrapper')?.classList.add('hidden');
        }
    });
});

