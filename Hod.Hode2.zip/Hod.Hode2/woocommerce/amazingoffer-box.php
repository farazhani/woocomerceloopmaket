<?php
/**
 * Template Part: WooCommerce Discount Slider
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// فقط محصولات دارای تخفیف
$args = array(
    'post_type'      => 'product',
    'posts_per_page' => 12,
    'meta_query'     => array(
        'relation' => 'AND',
        array(
            'key'     => '_sale_price',
            'value'   => 0,
            'compare' => '>',
            'type'    => 'NUMERIC'
        ),
        array(
            'key'     => '_stock_status',
            'value'   => 'instock',
        )
    )
);

$query = new WP_Query($args);
?>

<div class="lg:flex  mx-4 lg:mx-13  bg-[var(--amazing-box-color1)] p-5 lg:p-4 my-8 rounded-2xl shadow-lg relative">

  <!-- باکس تبلیغ -->
  <div class="flex mb-5 lg:m-2 flex-col items-center justify-center bg-[var(--amazing-box-color2)] text-white lg:w-[23%] md:w-[100%] shadow-lg shadow-[#1c6c2d]/25 rounded-xl p-6   shrink-0">
    <h2 class="text-4xl leading-normal font-black mb-3 text-center">
      <spam class="text-[#10b5ce] text-shadow-md text-shadow-[#03535f]/50">تـــخـــفـــیـــف</spam>
</br><spam class="text-[#3bd834] text-shadow-md text-shadow-[#095a05]/50">هــــــــــــــــای</spam>
</br><spam class="text-[#ff9000] text-shadow-md text-shadow-[#844604]/50">شگفت انگیز</spam>
    </h2>
    <a href="<?php echo wc_get_page_permalink( 'shop' ); ?>"
      class="bg-[var(--amazing-box-color1)] hover:border hover:border-[var(--amazing-box-color1)] hover:bg-[#0ca133]/0 hover:text-[var(--amazing-box-color1)] text-white px-4 py-2 rounded-lg text-sm font-bold">مشاهده همه</a>
  </div>

  <!-- کانتینر اسلایدر محصول-->
  <div id="sliderContainer" class="relative lg:m-2 overflow-x-auto snap-x snap-mandatory rounded-lg lg:mr-4 scrollbar-hidden" style="scrollbar-width: none;">
    <div id="slider" class="flex transition-transform duration-500" >

      <?php if ( $query->have_posts() ) : ?>
        <?php while ( $query->have_posts() ) : $query->the_post();
          global $product;
          if ( ! $product ) continue;

          $sale_price = $product->get_sale_price();
          $regular_price = $product->get_regular_price();
          $discount_percent = round( ( ( $regular_price - $sale_price ) / $regular_price ) * 100 );
        ?>
        
          <div
            class="slide relative snap-start bg-white w-40 lg:w-55 rounded-lg p-3 flex flex-col items-center shadow mx-2 shrink-0">

            <div class="relative">
            <a href="<?php the_permalink(); ?>">
              
              <?php echo $product->get_image( 'woocommerce_thumbnail', array( 'class' => 'w-auto h-auto  rounded-lg' ) ); ?>
            </a>
            <a href="<?php echo esc_url( $product->add_to_cart_url() ); ?>"
              class="bottom-1 right-1 bg-[var(--primary-color)] absolute text-white rounded-full w-8 h-8 flex items-center justify-center hover:bg-[var(--secondary-color-1)] shadow-md transition"
              aria-label="افزودن">+</a>

            </div>
            <p class="text-xs text-gray-700 mt-2 text-center"><?php the_title(); ?></p>

            <div class="flex items-center justify-between w-full mt-2">
              <span class="bg-[var(--primary-color)] text-white text-xs px-2 py-1 rounded-lg"><?php echo $discount_percent; ?>٪</span>
              <span class="line-through text-gray-400 text-xs">
                <?php echo wc_price( $regular_price ); ?>
              </span>
            </div>

            <p class="text-green-600 font-bold text-sm mt-1"><?php echo wc_price( $sale_price ); ?></p>





          </div>
        <?php endwhile; wp_reset_postdata(); ?>
      <?php else : ?>
        <p class="text-white p-4">هیچ محصول تخفیف‌داری موجود نیست.</p>
      <?php endif; ?>

    </div>


  </div>
</div>

<script>
  const slider = document.getElementById("slider");
  const container = document.getElementById("sliderContainer");
  const nextBtn = document.getElementById("nextBtn");
  const prevBtn = document.getElementById("prevBtn");

  function step() {
    const first = slider.querySelector(".slide");
    if (!first) return 300;
    const rect = first.getBoundingClientRect();
    const style = getComputedStyle(first);
    const margin = (parseFloat(style.marginLeft) || 0) + (parseFloat(style.marginRight) || 0);
    return rect.width + margin;
  }

  const isRTL = getComputedStyle(document.documentElement).direction === "rtl";

  nextBtn.addEventListener("click", () => {
    const distance = step();
    container.scrollBy({ left: isRTL ? -distance : distance, behavior: "smooth" });
  });

  prevBtn.addEventListener("click", () => {
    const distance = step();
    container.scrollBy({ left: isRTL ? distance : -distance, behavior: "smooth" });
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowLeft') prevBtn.click();
    if (e.key === 'ArrowRight') nextBtn.click();
  });
</script>
