<?php
$category = $args['category'] ?? ''; // آرایه‌ای که با get_template_part پاس شد
if ( empty($category) ) {
    echo '<p>دسته اسلایدر تعریف نشده!</p>';
    return;
}
?>

<?php
// $category رو از بیرون پاس بده (home-slider یا shop-slider)
if ( empty($category) ) return;

$args = array(
  'post_type'      => 'slide',
  'posts_per_page' => -1,
  'orderby'        => 'date',
  'order'          => 'ASC',
  'tax_query'      => array(
    array(
      'taxonomy' => 'slide_cat',
      'field'    => 'slug',
      'terms'    => $category,
    ),
  ),
);
$slides = new WP_Query($args);
 echo '<pre>'; print_r($slides); echo '</pre>';
if ($slides->have_posts()) :
  $uid = uniqid('slider_'); // ساختن ID یکتا برای هر اسلایدر
?>
  <div id="<?php echo $uid; ?>" class="custom-slider relative w-full mx-auto overflow-hidden rounded-xl shadow-lg">
    <div class="slider-track flex transition-transform  duration-500">
      <?php while ($slides->have_posts()) : $slides->the_post(); ?>
        <div class="w-full flex-shrink-0 relative">
          <?php the_post_thumbnail('large', ['class' => 'w-full h-auto']); ?>
          <div class="absolute bottom-3 left-3 bg-black/50 text-white text-sm px-3 py-1 rounded">
            <?php the_title(); ?>
          </div>
        </div>
      <?php endwhile; ?>
    </div>

    <!-- دکمه‌ها -->
    <button class="slider-prev absolute top-1/2 -translate-y-1/2 left-3 bg-white/70 hover:bg-white text-gray-700 rounded-full p-2 shadow">◀</button>
    <button class="slider-next absolute top-1/2 -translate-y-1/2 right-3 bg-white/70 hover:bg-white text-gray-700 rounded-full p-2 shadow">▶</button>

    <!-- دات‌ها -->
    <div class="slider-dots absolute bottom-3 left-1/2 -translate-x-1/2 flex space-x-2"></div>
  </div>

  <script>
    (function() {
      const root   = document.getElementById('<?php echo $uid; ?>');
      if (!root) return;

      const slider = root.querySelector('.slider-track');
      const slides = slider.children.length;
      const prev   = root.querySelector('.slider-prev');
      const next   = root.querySelector('.slider-next');
      const dots   = root.querySelector('.slider-dots');

      let index = 0;
      let interval;

      function showSlide(i) {
        index = (i + slides) % slides;
        slider.style.transform = `translateX(-${index * 100}%)`;
        updateDots();
      }

      function updateDots() {
        [...dots.children].forEach((dot, i) => {
          dot.classList.toggle('bg-white', i === index);
          dot.classList.toggle('bg-gray-400', i !== index);
        });
      }

      // ساخت دات‌ها
      for (let i = 0; i < slides; i++) {
        const dot = document.createElement('span');
        dot.className = 'w-3 h-3 rounded-full bg-gray-400 cursor-pointer';
        dot.onclick = () => showSlide(i);
        dots.appendChild(dot);
      }

      prev.onclick = () => showSlide(index - 1);
      next.onclick = () => showSlide(index + 1);

      function startAuto() {
        interval = setInterval(() => showSlide(index + 1), 3000);
      }
      function stopAuto() {
        clearInterval(interval);
      }

      root.addEventListener('mouseenter', stopAuto);
      root.addEventListener('mouseleave', startAuto);

      // شروع
      showSlide(0);
      startAuto();
    })();
  </script>
<?php endif; wp_reset_postdata(); ?>
