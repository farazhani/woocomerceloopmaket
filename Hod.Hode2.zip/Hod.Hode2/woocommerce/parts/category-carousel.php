<?php
$uid = uniqid('catcrsl_');
$product_cats = get_terms([
  'taxonomy' => 'product_cat',
  'hide_empty' => false,
  'orderby' => 'name',
  'order' => 'ASC',
]);

if (is_wp_error($product_cats) || empty($product_cats))
  return;
?>

<style>
  #<?php echo esc_attr($uid); ?> .no-scrollbar::-webkit-scrollbar {
    display: none;
  }

  #<?php echo esc_attr($uid); ?> .no-scrollbar {
    -ms-overflow-style: none;
    scrollbar-width: none;
  }
</style>
<?php
//  دریافت تنظیمات blocks2
$show_blocks2 = get_theme_mod('show_blocks2', true);
$radius_class = get_theme_mod('blocks2_radius_class', 'rounded-lg');
$bg_color = get_theme_mod('blocks2_bg_color', '#ffffff');

// سایه سفارشی
$shadow_x = get_theme_mod('blocks2_shadow_x', '0px');
$shadow_y = get_theme_mod('blocks2_shadow_y', '4px');
$shadow_blur = get_theme_mod('blocks2_shadow_blur', '10px');
$shadow_spread = get_theme_mod('blocks2_shadow_spread', '0px');
$shadow_color = get_theme_mod('blocks2_shadow_color', 'rgba(0,0,0,0.3)');

$box_shadow = "box-shadow: {$shadow_x} {$shadow_y} {$shadow_blur} {$shadow_spread} {$shadow_color};";
?>

<?php if ($show_blocks2 && !empty($product_cats)): ?>
  <div id="blocks2-wrapper" class="relative -mt-48 w-full max-w-6xl mx-auto px-0">
    <div class="relative">

      <!-- دکمه چپ -->
      <button type="button"
        class="carousel-prev absolute top-1/2 left-0 -translate-y-1/2 hover:bg-gray-300/50 text-2xl text-gray-600 p-3 rounded-full z-30">
        ›
      </button>

      <!-- لیست دسته‌ها -->
      <div class="flex px-3 justify-center relative">
        <div
          class="carousel-track flex overflow-x-auto no-scrollbar space-x-6 scroll-smooth py-10 h-auto justify-start px-7">
          <?php foreach ($product_cats as $cat): ?>
            <div
              class="blocks2-item flex flex-col items-center shrink-0 w-24 transform transition duration-300 hover:scale-110 hover:-translate-y-2 origin-center <?php echo esc_attr($radius_class); ?>"
              style="background-color: <?php echo esc_attr($bg_color); ?>; <?php echo esc_attr($box_shadow); ?>">

              <a href="<?php echo esc_url(get_term_link($cat)); ?>" class="flex flex-col items-center p-2">
                <div class="w-17 h-17 flex items-center justify-center rounded-full overflow-hidden">
                  <?php
                  $thumbnail_id = get_term_meta($cat->term_id, 'thumbnail_id', true);
                  if ($thumbnail_id) {
                    echo wp_get_attachment_image($thumbnail_id, 'thumbnail', false, ['class' => 'w-12 h-12 object-cover']);
                  } else {
                    echo '<span aria-hidden="true">📦</span>';
                  }
                  ?>
                </div>
                <span class="mt-2 text-sm text-gray-700 text-center">
                  <?php echo esc_html($cat->name); ?>
                </span>
              </a>
            </div>
          <?php endforeach; ?>
        </div>
      </div>

      <!-- دکمه راست -->
      <button type="button"
        class="carousel-next absolute top-1/2 right-0 -translate-y-1/2 hover:bg-gray-300/50 text-2xl text-gray-600 p-3 rounded-full z-30">
        ‹
      </button>
    </div>
  </div>
<?php endif; ?>


<script>
  (function () {
    var root = document.getElementById('<?php echo esc_js($uid); ?>');
    if (!root) return;

    var track = root.querySelector('.carousel-track');
    var nextBtn = root.querySelector('.carousel-next');
    var prevBtn = root.querySelector('.carousel-prev');
    var scrollAmount = 200;

    function goNext(e) {
      if (e) { e.preventDefault(); e.stopPropagation(); }
      track.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
    function goPrev(e) {
      if (e) { e.preventDefault(); e.stopPropagation(); }
      track.scrollBy({ left: -scrollAmount, behavior: 'smooth' });
    }

    nextBtn.addEventListener('click', goNext);
    prevBtn.addEventListener('click', goPrev);
  })();
</script>