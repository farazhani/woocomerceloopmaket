<?php
defined( 'ABSPATH' ) || exit;

global $product;

if ( empty( $product ) || ! $product->is_visible() ) {
    return;
}
?>
<?php
  $sale_price    = $product->get_sale_price();
  $regular_price = $product->get_regular_price();

  if ( $sale_price && $sale_price < $regular_price ) {
      $discount_percent = round( ( ( $regular_price - $sale_price ) / $regular_price ) * 100 );
  }
  else $discount_percent=0
?>


<div class="slide snap-start min-w-[44%] md:min-w-[23%]">
  <div class="group relative bg-white rounded-xl shadow-md transition-transform duration-200 p-4 text-center 
                hover:shadow-xl transform-gpu will-change-transform hover:scale-105 overflow-visible">
      <!-- دکمه افزودن به سبد خرید -->
      <a data-product-id="123" href="<?php echo esc_url( $product->add_to_cart_url() ); ?>"
              class=" absolute text-lg flex items-center justify-center w-10 h-10 lg:top-51 md:top-55 right-5 bg-[var(--primary-color)] hover:bg-[var(--secondary-color-1)] text-white rounded-full shadow-md transition hover:shadow-lg hover:shadow-[var(--secondary-color-1)]">
        +
</a>

    <a href="<?php the_permalink(); ?>">

      <?php
        // عکس محصول
        echo $product->get_image( 'woocommerce_thumbnail', [ 'class' => 'w-full h-full  rounded-lg' ] );
      ?>
      <h3 class="mt-3 text-sm font-bold"><?php the_title(); ?></h3>

    <div class="flex items-center justify-between w-full mt-2">
      <span class="bg-[var(--primary-color)] text-white text-xs px-2 py-1 rounded-lg">
        <?php echo $discount_percent; ?>٪
      </span>
      <span class="line-through text-gray-400 text-xs">
        <?php  if($discount_percent!=0){ echo wc_price( $regular_price ); }?>
      </span>
    </div>

            <p class="text-green-600 font-bold text-sm mt-1"><?php if($discount_percent==0){ echo wc_price( $regular_price );} else echo wc_price( $sale_price );  ?></p>
      <!-- <p class="mt-2 font-bold text-blue-500">
        <?php //echo $product->get_price_html(); ?>
      </p> -->
    </a>
  </div>
</div>
<script>
document.querySelectorAll(".add-to-cart").forEach(btn => {
  btn.addEventListener("click", function () {
    const productId = this.getAttribute("data-product-id");

    fetch(wc_add_to_cart_params.ajax_url, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        action: "woocommerce_ajax_add_to_cart",
        product_id: productId,
        quantity: 1,
      })
    })
    .then(res => res.json())
    .then(data => {
      if (data.error && data.product_url) {
        window.location = data.product_url;
      } else {
        // ✅ پیام موفقیت
        alert("محصول به سبد خرید اضافه شد ✔");
        
        // ✅ اگر می‌خواید مینی‌کارت ووکامرس هم آپدیت بشه:
        document.body.dispatchEvent(new Event("wc_fragment_refresh"));
      }
    });
  });
});
</script>












