<section class="flex flex-col my-6  sm:flex-row w-full">
  <?php
  $args = array(
      'post_type'      => 'banner',
      'posts_per_page' => 3, // فقط 3 تا بنر
      'tax_query'      => array(
          array(
              'taxonomy' => 'banner_category',
              'field'    => 'slug',
              'terms'    => 'front-page-t', // اسم دسته (نامک slug دسته B1)
          ),
      ),
  );
  $banners = new WP_Query($args);
?>
<div class=" lg:flex mb-10 mx-4 lg:mx-10 gap-5 ">
<?php
  if ($banners->have_posts()) :
      while ($banners->have_posts()) : $banners->the_post(); ?>
          <div class=" w-full">
              <a href="<?php the_permalink(); ?>">
                  <?php the_post_thumbnail('full', array('class' => 'w-full my-3 h-auto rounded-lg')); ?>
              </a>
          </div>
      <?php endwhile;
      wp_reset_postdata();
  else :
      echo "<p>هیچ بنری پیدا نشد</p>";
  endif;
  ?>
  </div>
</section>
